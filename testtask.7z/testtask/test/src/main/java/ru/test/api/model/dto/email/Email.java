package ru.test.api.model.dto.email;

public record Email(@jakarta.validation.constraints.Email String email) {
}
