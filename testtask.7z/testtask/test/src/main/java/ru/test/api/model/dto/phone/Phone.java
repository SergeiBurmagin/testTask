package ru.test.api.model.dto.phone;


public record Phone(String phone) {
}