package ru.test.api.model.dto.respomse;

public record TokenResponse(String accessToken) {

}
